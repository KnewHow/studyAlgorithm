key = getPivotByRandom(a, left, right);
		low = left;
		high = right;
		while (low < high) {
			while (low < high && a[high] > key) {
				high--;
			}
			a[low] = a[high];
			while (low < high && a[low] < key) {
				low++;
			}
			a[high] = a[low];
		}
		a[low] = key;
		quicksort(a, left, low - 1);
		quicksort(a, low + 1, right);
