#include<stdio.h>
#include<stdlib.h>

typedef int elemetType;
typedef struct node{
    int currentAddress;
    elemetType
}

int main(){
    printf("just test\n");
    return 0;
}
