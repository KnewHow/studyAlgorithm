BinTree Insert( BinTree BST, ElementType X ){
    if(!BST) {          /* 若原树为空，生成并返回一个结点的二叉搜索树 */
        BST = (BinTree)malloc(sizeof(struct TNode));
        BST ->Data = X;
        BST ->Left = BST ->Right = NULL;
    }else {         /* 开始寻找要插入元素的位置 */
        if(X < BST ->Data ) {
            BST ->Left = Insert(BST ->Left, X);
        }else if(X > BST ->Data ) {
            BST ->Right = Insert(BST ->Right, X);
        }
        /* X已经存在，不用操作 */
    }
    return BST;
} 
BinTree Delete( BinTree BST, ElementType X ){
    Position Tmp;
    if(!BST)    printf("Not Found\n");
    else {
        if( X < BST->Data)  
            BST ->Left = Delete(BST->Left, X);          /* 左子树递归删除 */
        else if(X > BST->Data ) 
            BST ->Right = Delete(BST->Right , X);       /* 右子树递归删除*/
        else {                                          /* 找到需要删除的结点 */
            if(BST->Left && BST->Right) {               /* 被删除的结点有左右子结点 */
                Tmp=FindMin(BST->Right);                /* 在右子树中找到最小结点填充删除结点 */
                BST->Data = Tmp ->Data;
                BST->Right=Delete(BST->Right,BST->Data);/* 递归删除要删除结点的右子树中最小元素 */
            }else {                                     /* 被删除结点有一个或没有子结点*/
                Tmp = BST;
                if(!BST->Left) BST = BST->Right;        /*有右孩子或者没孩子*/ 
                else if(!BST->Right)    BST = BST->Left;/*有左孩子，一定要加else，不然BST可能是NULL，会段错误*/ 
                free(Tmp);                              /*如无左右孩子直接删除*/
            }
        }
    }
    return BST;
}
Position Find( BinTree BST, ElementType X ){
    if(!BST)    return NULL;
    if(BST->Data==X)    return BST; 
    if(X>BST->Data)     return Find(BST->Right,X);      
    if(X<BST->Data)     return Find(BST->Left,X);

    /*  以下几种写法均可，推荐第上面这一种 

    if(!BST)    return NULL;
    if(BST->Data==X)    return BST; 
    if(X>BST->Data)     Find(BST->Right,X);     
    if(X<BST->Data)     Find(BST->Left,X);

    if(BST){
        if(BST->Data==X)    return BST; 
        if(X>BST->Data)     Find(BST->Right,X);     //如果不写return，则返回过来的值并没有继续返回给最开始的函数 
        if(X<BST->Data)     Find(BST->Left,X);
    } 
    else return NULL;   

    if(BST){
        if(BST->Data==X)    return BST; 
        if(X>BST->Data)     return  Find(BST->Right,X); 
        if(X<BST->Data)     return  Find(BST->Left,X);
    } 
    return NULL;

    if(BST){
        if(BST->Data==X)    return BST; 
        if(X>BST->Data)     return Find(BST->Right,X);      
        if(X<BST->Data)     return Find(BST->Left,X);
    } 
    else return NULL;
    */                          
}
/*如果return NULL前面不写else且Find前也不写else，则最后递归返回的也没return，最后只能是执行到了return NULL
返回了，而如果find 前加上了return则就把递归的结果利用起来了，最后加不加else也无所谓了，而如果直接最后else，
不加return find也是可以的，加上了else之后就不会被每一次返回时最后的return NULL给覆盖掉，所以也行。 */ 
Position FindMin( BinTree BST ){
    if(BST){
        while(BST->Left){
            BST=BST->Left;
        }
    } 
    return BST; 
} 
Position FindMax( BinTree BST ){
    if(BST){
        while(BST->Right){
            BST=BST->Right;
        }
    } 
    return BST; 
}
